#include "header.h"

int main(int argc, char *argv[]) {
    GameState game;
    
    if(SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0) {
        fprintf(stderr, "SDL init failed: %s\n", SDL_GetError());
        return 1;
    }
    
    init_game(&game);
    
    while(!game.quit) {
        handle_events(&game);
        update_game(&game);
        draw_game(&game);
        SDL_Delay(16);
    }
    
    clean_up(&game);
    return 0;
}
