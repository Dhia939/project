#include "header.h"

int rects_intersect(const SDL_Rect *A, const SDL_Rect *B) {
    return !(A->x + A->w < B->x || 
             B->x + B->w < A->x || 
             A->y + A->h < B->y || 
             B->y + B->h < A->y);
}

void init_game(GameState *game) {
    if(Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
        fprintf(stderr, "SDL_mixer error: %s\n", Mix_GetError());
        exit(1);
    }

    game->correct_sound = Mix_LoadWAV("corr.wav");
    game->incorrect_sound = Mix_LoadWAV("wrong.wav");
    if(!game->correct_sound || !game->incorrect_sound) {
        fprintf(stderr, "Sound loading error: %s\n", Mix_GetError());
    }
     
    game->screen = SDL_SetVideoMode(1920, 900, 32, SDL_SWSURFACE);
    if(!game->screen) {
        fprintf(stderr, "Video mode error: %s\n", SDL_GetError());
        exit(1);
    }

    if(TTF_Init() == -1) {
        fprintf(stderr, "TTF init error: %s\n", TTF_GetError());
        exit(1);
    }

    game->font = TTF_OpenFont("pol.ttf", 48);
    if(!game->font) {
        fprintf(stderr, "Font loading error: %s\n", TTF_GetError());
        exit(1);
    }

    SDL_WM_SetCaption("Puzzle Game", NULL);
    load_images(game);
    
    game->missing_position.x = 510;
    game->missing_position.y = 300;
    game->missing_position.w = 200;
    game->missing_position.h = 200;
    
    for(int i = 0; i < PUZZLE_PIECES; i++) {
        game->pieces[i].position.x = 950 + i * 200;
        game->pieces[i].position.y = 200;
        game->pieces[i].position.w = 100;
        game->pieces[i].position.h = 100;
        game->pieces[i].is_dragging = 0;
        game->pieces[i].is_correct = (i == 1); 
    }
    
    game->game_over = 0;
    game->quit = 0;
    game->show_feedback = 0;
    game->feedback_correct = 0;
    game->start_time = SDL_GetTicks();
    game->time_limit = 30000;
    game->zoom_active = 0;
    game->zoom_scale = 1.0f;
    game->zoom_start_time = 0;
}

void load_images(GameState *game) {
    game->background = SDL_LoadBMP("bg.bmp");
    if(!game->background) {
        fprintf(stderr, "Background error: %s\n", SDL_GetError());
        exit(1);
    }
    
    game->correct_feedback = SDL_LoadBMP("pic1.bmp");
    game->incorrect_feedback = SDL_LoadBMP("pic2.bmp");
    if(!game->correct_feedback || !game->incorrect_feedback) {
        fprintf(stderr, "Feedback image error: %s\n", SDL_GetError());
        exit(1);
    }
    
    game->pieces[0].image = SDL_LoadBMP("p2.bmp");
    game->pieces[1].image = SDL_LoadBMP("p1.bmp");
    game->pieces[2].image = SDL_LoadBMP("p3.bmp");
    
    for(int i = 0; i < PUZZLE_PIECES; i++) {
        if(!game->pieces[i].image) {
            fprintf(stderr, "Piece %d error: %s\n", i, SDL_GetError());
            exit(1);
        }
    }
}

void handle_events(GameState *game) {
    SDL_Event event;
    
    while(SDL_PollEvent(&event)) {
        switch(event.type) {
            case SDL_QUIT:
                game->quit = 1;
                break;
                
            case SDL_MOUSEBUTTONDOWN:
                if(event.button.button == SDL_BUTTON_LEFT && !game->game_over) {
                    for(int i = 0; i < PUZZLE_PIECES; i++) {
                        SDL_Rect mouse = {event.button.x, event.button.y, 1, 1};
                        if(rects_intersect(&mouse, &game->pieces[i].position)) {
                            game->pieces[i].is_dragging = 1;
                        }
                    }
                }
                break;
                
         
case SDL_MOUSEBUTTONUP:
    if(event.button.button == SDL_BUTTON_LEFT && !game->game_over) {
        for(int i = 0; i < PUZZLE_PIECES; i++) {
            if(game->pieces[i].is_dragging) {
                game->pieces[i].is_dragging = 0;
                
                if(rects_intersect(&game->pieces[i].position, &game->missing_position)) {
                    if(game->pieces[i].is_correct) {
                        Mix_PlayChannel(-1, game->correct_sound, 0);
                        game->game_over = 1;
                        game->show_feedback = 1;
                        game->feedback_correct = 1;
                        game->zoom_active = 1;
                        game->zoom_start_time = SDL_GetTicks();
                    } else {
                        Mix_PlayChannel(-1, game->incorrect_sound, 0);
                        game->show_feedback = 1;
                        game->feedback_correct = 0;
                        game->zoom_active = 1; 
                        game->zoom_start_time = SDL_GetTicks();  
                    }
                }
            }
        }
    }
    break;
                
            case SDL_MOUSEMOTION:
                if(!game->game_over) {
                    for(int i = 0; i < PUZZLE_PIECES; i++) {
                        if(game->pieces[i].is_dragging) {
                            game->pieces[i].position.x = event.motion.x - game->pieces[i].position.w/2;
                            game->pieces[i].position.y = event.motion.y - game->pieces[i].position.h/2;
                        }
                    }
                }
                break;
        }
    }
}

void update_game(GameState *game) {
    if(!game->game_over && (SDL_GetTicks() - game->start_time > game->time_limit)) {
        game->game_over = 1;
        game->show_feedback = 1;
        game->feedback_correct = 0;
        game->zoom_active = 1;  // Add this line
        game->zoom_start_time = SDL_GetTicks();  // Add this line
        Mix_PlayChannel(-1, game->incorrect_sound, 0);
    }
    
    if(game->zoom_active) {
        Uint32 now = SDL_GetTicks();
        float progress = (now - game->zoom_start_time) / 500.0f;
        game->zoom_scale = 1.0f + 0.5f * (progress < 1.0f ? progress : 1.0f);
        if(progress >= 1.0f) game->zoom_active = 0;
    }
}

void draw_game(GameState *game) {
    SDL_FillRect(game->screen, NULL, SDL_MapRGB(game->screen->format, 255, 255, 255));
    apply_surface(0, 0, game->background, game->screen);
    
    // Draw puzzle area
    SDL_FillRect(game->screen, &game->missing_position, SDL_MapRGB(game->screen->format, 50, 50, 50));
    
    // Draw pieces
    for(int i = 0; i < PUZZLE_PIECES; i++) {
        apply_surface(game->pieces[i].position.x, game->pieces[i].position.y, 
                     game->pieces[i].image, game->screen);
    }
    
    // Draw timer
    float progress = (float)(SDL_GetTicks() - game->start_time) / game->time_limit;
    SDL_Rect timer = {20, 20, (int)((SCREEN_WIDTH-40)*(1-progress)), 20};
    SDL_FillRect(game->screen, &timer, SDL_MapRGB(game->screen->format, 
        255 * progress, 255 * (1-progress), 0));
    
    // Draw feedback
    if(game->show_feedback) {
        SDL_Surface* feedback = game->feedback_correct ? 
            game->correct_feedback : game->incorrect_feedback;
        
        if(game->zoom_active) {
            SDL_Rect dest = {
                SCREEN_WIDTH/2 - feedback->w*game->zoom_scale/2,
                SCREEN_HEIGHT/2 - feedback->h*game->zoom_scale/2,
                feedback->w * game->zoom_scale,
                feedback->h * game->zoom_scale
            };
            SDL_Surface* scaled = SDL_CreateRGBSurface(SDL_SWSURFACE, 
                dest.w, dest.h, 32, 0,0,0,0);
            SDL_SoftStretch(feedback, NULL, scaled, NULL);
            apply_surface(dest.x, dest.y, scaled, game->screen);
            SDL_FreeSurface(scaled);
        } else {
            apply_surface(SCREEN_WIDTH/2 - feedback->w/2, 
                        SCREEN_HEIGHT/2 - feedback->h/2, 
                        feedback, game->screen);
        }
        
        // Draw text
        SDL_Color black = {255,255,255};
        SDL_Surface* text = TTF_RenderText_Solid(game->font, 
            game->feedback_correct ? "Correct!" : "Wrong!", black);
        if(text) {
            apply_surface(SCREEN_WIDTH/2 - text->w/2, 
                         SCREEN_HEIGHT/2 + feedback->h/2 + 20, 
                         text, game->screen);
            SDL_FreeSurface(text);
        }
    }
    
    SDL_Flip(game->screen);
}

void apply_surface(int x, int y, SDL_Surface* src, SDL_Surface* dst) {
    SDL_Rect pos = {x, y};
    SDL_BlitSurface(src, NULL, dst, &pos);
}

void clean_up(GameState *game) {
    Mix_FreeChunk(game->correct_sound);
    Mix_FreeChunk(game->incorrect_sound);
    Mix_CloseAudio();
    
    SDL_FreeSurface(game->background);
    SDL_FreeSurface(game->correct_feedback);
    SDL_FreeSurface(game->incorrect_feedback);
    
    for(int i = 0; i < PUZZLE_PIECES; i++) {
        SDL_FreeSurface(game->pieces[i].image);
    }
    
    TTF_CloseFont(game->font);
    TTF_Quit();
    SDL_Quit();
}
