#ifndef HEADER_H
#define HEADER_H

#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <SDL/SDL_ttf.h>

#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 600
#define PUZZLE_PIECES 3

typedef struct {
    SDL_Surface *image;
    SDL_Rect position;
    int is_dragging;
    int is_correct;
} PuzzlePiece;

typedef struct {
    SDL_Surface *screen;
    SDL_Surface *background;
    SDL_Surface *correct_feedback;
    SDL_Surface *incorrect_feedback;
    
    PuzzlePiece pieces[PUZZLE_PIECES];
    SDL_Rect missing_position;
    
    int game_over;
    int quit;
    int show_feedback;
    int feedback_correct;
    
    Uint32 start_time;
    Uint32 time_limit;
    
    TTF_Font *font;
    int zoom_active;
    float zoom_scale;
    Uint32 zoom_start_time;

    Mix_Chunk *correct_sound;
    Mix_Chunk *incorrect_sound;
} GameState;

int rects_intersect(const SDL_Rect *A, const SDL_Rect *B);
void init_game(GameState *game);
void load_images(GameState *game);
void handle_events(GameState *game);
void update_game(GameState *game);
void draw_game(GameState *game);
void apply_surface(int x, int y, SDL_Surface *source, SDL_Surface *destination);
void clean_up(GameState *game);

#endif
