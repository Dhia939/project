
#include "Text.h"

void initText(Text *t)//n3mr les donnes du text 
{
    t->position.x = 500;
    t->position.y = 200;
    t->textColor.r = 100;
    t->textColor.g = 150;
    t->textColor.b = 100;
    t->font = TTF_OpenFont("pol.ttf", 50);
}
void freeText(Text A)
{
    SDL_FreeSurface(A.surfaceTexte);
}
void displayText(Text t, SDL_Surface *screen)
{
    t.surfaceTexte = TTF_RenderText_Solid(t.font, "Menu Joueur ", t.textColor);//fi west el variable t.surfacetext ctji el klma bil font o taille o colleur
    SDL_BlitSurface(t.surfaceTexte, NULL, screen, &t.position);//chnhot el kelma fil screen fil position ili 3amartha
}
