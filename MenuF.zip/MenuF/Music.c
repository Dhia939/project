
#include "Music.h"

void initMus(Music *M)
{
    Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, MIX_DEFAULT_CHANNELS, 1024);
    Mix_VolumeMusic(100);//fct teb3 sdl cht5dmli sout b volume mo3ayen
    M->music = Mix_LoadMUS("son.mp3");
    Mix_PlayMusic(M->music, -1);
    M->bref = Mix_LoadWAV("taksir.wav");
}

void freeMusic(Music M)
{
    Mix_FreeMusic(M.music);
    Mix_FreeChunk(M.bref);
    Mix_CloseAudio();
    Mix_Quit();
}

