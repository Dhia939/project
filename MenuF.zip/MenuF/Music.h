#ifndef MUSIC
#define MUSIC
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>

typedef struct
{
    Mix_Music *music;
    Mix_Chunk *bref;
} Music;

void initMus(Music *M);
void freeMusic(Music M);


#endif /* MUSIC */
