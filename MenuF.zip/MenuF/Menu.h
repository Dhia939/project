#ifndef MENU
#define MENU
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_image.h>
//////////////////////////////
void NewGame(SDL_Surface *screen);
void sauvgarder(SDL_Surface *screen);
void NewGame2(SDL_Surface *screen);

void NewGame3(SDL_Surface *screen);

void NewGame4(SDL_Surface *screen);
//////////////////////////////



#endif /* MENU */
