

#include "Menu.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_image.h>
#include<SDL/SDL_mixer.h>
#include "Text.h"
#include "Music.h"
void NewGame(SDL_Surface *screen)//bich kif nenzel 3ala bouton newgame n3aytlil fct hedi chtjibli background ekher
{
   
    SDL_Event event;//5tr chn3ml event bich nkiti
    int continuer = 1;
    SDL_Surface *background=NULL;
    SDL_Surface *input1=NULL;
    SDL_Surface *input2=NULL;
    SDL_Surface *input1N=NULL;
    SDL_Surface *input2N=NULL;
    SDL_Surface *avatar1=NULL;
    SDL_Surface *avatar2=NULL;
     SDL_Surface *avatar1N=NULL;
    SDL_Surface *avatar2N=NULL;
    SDL_Surface *valider=NULL;
    SDL_Surface *back=NULL;
    Music M;
    Text t;
 initMus(&M);
    SDL_Surface *validerN=NULL;
    SDL_Surface *backN=NULL;
    SDL_Rect positionbackground;
    SDL_Rect input11;
    SDL_Rect avatar11;
    SDL_Rect back1;
    SDL_Rect input22;
    SDL_Rect avatar22;
    SDL_Rect valider1;
 
 
 background=IMG_Load("background.png");
  input1=IMG_Load("inp1.png");
   input2=IMG_Load("inp2.png");
    back=IMG_Load("back.png");
    avatar1=IMG_Load("av1.png");
     avatar2=IMG_Load("av2.png");
      valider=IMG_Load("apply.png");
      
      input1N=IMG_Load("inp1_hover.png");
   input2N=IMG_Load("inp2_hover.png");
      backN=IMG_Load("back_hover.png");
    avatar1N=IMG_Load("av1_hover.png");
     avatar2N=IMG_Load("av2_hover.png");
      validerN=IMG_Load("apply_hover.png");
 positionbackground.x=0;
 positionbackground.y=0;
 
 
  input11.x=250;
 input11.y=200;
 
   input22.x=250;
 input22.y=350;
 
 
 
  avatar11.x=650;
 avatar11.y=200;
 
   avatar22.x=650;
 avatar22.y=350;
   valider1.x=450;
 valider1.y=500;
    back1.x=1000;
 back1.y=500;
 
 
    while (continuer)
    {
        SDL_BlitSurface(background,NULL,screen,&positionbackground);
        
                SDL_BlitSurface(input1,NULL,screen,&input11);
                SDL_BlitSurface(input2,NULL,screen,&input22);
                SDL_BlitSurface(avatar1,NULL,screen,&avatar11);
                SDL_BlitSurface(avatar2,NULL,screen,&avatar22);
                SDL_BlitSurface(valider,NULL,screen,&valider1);
                SDL_BlitSurface(back,NULL,screen,&back1);
       
        SDL_PollEvent(&event);//programme yok3ed y5dem o wa9t ana n3ml event howa y3mili execution mta3ha 33aks waitevent tstnaik hata ta3tiha event
        switch (event.type)
        {
        case SDL_QUIT:
            continuer = 0;

                            sauvgarder(screen);
        
            break;
        case SDL_KEYDOWN://si chnenzel 3al clavier 
            switch (event.key.keysym.sym)
            {
            case SDLK_ESCAPE:
                continuer = 0;
                printf("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhh");
              
                break;
            }
            break;
            
            case SDL_MOUSEMOTION://harakt souris



                if (event.motion.x > 250 && event.motion.x < 250+236 && event.motion.y > 200 && event.motion.y < 280)
                {
                SDL_BlitSurface(input1N,NULL,screen,&input11);
                                                             Mix_PlayChannel(-1, M.bref, 0);

                }
             else if(event.motion.x > 250 && event.motion.x < 250+251 && event.motion.y > 350 && event.motion.y < 350+80)
               {
                SDL_BlitSurface(input2N,NULL,screen,&input22);
                                                             Mix_PlayChannel(-1, M.bref, 0);

               }
               
                else if(event.motion.x > 650 && event.motion.x < 650+239 && event.motion.y > 200 && event.motion.y < 200+80)
               {
                SDL_BlitSurface(avatar1N,NULL,screen,&avatar11);
                                                             Mix_PlayChannel(-1, M.bref, 0);

               }
               
                  else if(event.motion.x > 650 && event.motion.x < 650+235 && event.motion.y > 350 && event.motion.y < 350+80)
               {
                SDL_BlitSurface(avatar2N,NULL,screen,&avatar22);
                                                             Mix_PlayChannel(-1, M.bref, 0);

               }
               
                  else if(event.motion.x > 450 && event.motion.x < 450+240 && event.motion.y > 500 && event.motion.y < 500+80)
               {
                SDL_BlitSurface(validerN,NULL,screen,&valider1);
                                                             Mix_PlayChannel(-1, M.bref, 0);

               }
                  else if(event.motion.x > 1000 && event.motion.x < 1234 && event.motion.y > 500 && event.motion.y < 500+80)
               {
                SDL_BlitSurface(backN,NULL,screen,&back1);
                                                             Mix_PlayChannel(-1, M.bref, 0);

               }
               break;
               
               case SDL_MOUSEBUTTONUP:
                    if (event.button.button == SDL_BUTTON_LEFT)
                  {
           
               
                   if(event.motion.x > 450 && event.motion.x < 450+240 && event.motion.y > 500 && event.motion.y < 500+80)
               {
                   NewGame2(screen);


               }
                  else if(event.motion.x > 1000 && event.motion.x < 1234 && event.motion.y > 500 && event.motion.y < 500+80)
               {
                      continuer = 0;

                            sauvgarder(screen);


               }
                  
                  }
                  break;
        }
        
         SDL_Flip(screen);//refrech

    }

}   

void sauvgarder(SDL_Surface *screen)
{//

int continuer=1;
 TTF_Init();
 
 SDL_Surface *background=NULL;
 SDL_Surface *mono1=NULL;
 SDL_Surface *mono2=NULL;
 SDL_Surface *multiple1=NULL;
 SDL_Surface *multiple2=NULL;
  SDL_Surface *back1=NULL;
    SDL_Surface *back2=NULL;
 SDL_Rect positionbackground;
   SDL_Rect mono;
    SDL_Rect multiple;
        SDL_Rect back;
Music M;
Text t;
 initMus(&M);
SDL_Event event;

background=IMG_Load("background.png");
mono2=IMG_Load("mono_hover.png");
mono1=IMG_Load("mono.png");
multiple2=IMG_Load("multi_hover.png");
multiple1=IMG_Load("multi.png");

back2=IMG_Load("back_hover.png");

back1=IMG_Load("back.png");
back.x=1000;
back.y=500;

 positionbackground.x=0;
 positionbackground.y=0;
 
 mono.x=300;
 mono.y=350;
 multiple.x=750;
 multiple.y=350;
  /*positionbackground.w=940;
 positionbackground.h=532;*/
    initText(&t);

while(continuer==1)
{//
SDL_BlitSurface(background,NULL,screen,&positionbackground);

SDL_BlitSurface(mono1,NULL,screen,&mono);
SDL_BlitSurface(back1,NULL,screen,&back);
SDL_BlitSurface(multiple1,NULL,screen,&multiple);
                displayText(t, screen);
SDL_PollEvent(&event);
switch(event.type)
{//
case SDL_QUIT:
continuer=0;
break;

case SDL_KEYDOWN:
 switch (event.key.keysym.sym)
                    {
                    case SDLK_ESCAPE:
                        continuer = 0;
                        break;
                    case SDLK_m:


                       break;

                    }
break;


case SDL_MOUSEMOTION://harakt souris

printf("position de x  %d et position de y %d", event.motion.x,event.motion.y);

                if (event.motion.x > 300 && event.motion.x < 534 && event.motion.y > 350 && event.motion.y < 430)
                {
                     SDL_BlitSurface(mono2,NULL,screen,&mono);
                                             Mix_PlayChannel(-1, M.bref, 0);
                }
             else if(event.motion.x > 750 && event.motion.x < 978 && event.motion.y > 350 && event.motion.y < 350+80)
               {
                     SDL_BlitSurface(multiple2,NULL,screen,&multiple);
                                             Mix_PlayChannel(-1, M.bref, 0);
               }
               
                else if(event.motion.x > 1000 && event.motion.x < 1234 && event.motion.y > 500 && event.motion.y < 500+80)
               {
SDL_BlitSurface(back2,NULL,screen,&back);
                                             Mix_PlayChannel(-1, M.bref, 0);
               }
break;

case SDL_MOUSEBUTTONUP:
                    if (event.button.button == SDL_BUTTON_LEFT)
                    {
                        if (event.button.x > 300 && event.button.x < 534 && event.button.y > 350 && event.button.y < 430)
                        {
                            NewGame(screen);
                            
                        }
                        else if (event.button.x > 750 && event.button.x < 978 && event.button.y > 350 && event.button.y < 350+80)
                        {
                                                       NewGame(screen);
                        }
                        else if (event.button.x > 1000 && event.button.x < 1234 && event.button.y > 500 && event.button.y < 580)
                        {
                            continuer = 0;

                        }
                    }
                    break;
}//


SDL_Flip(screen);
}//


     freeText(t);
    TTF_CloseFont(t.font);
    TTF_Quit();
     SDL_Quit();
     
     }//


void NewGame2(SDL_Surface *screen)//bich kif nenzel 3ala bouton newgame n3aytlil fct hedi chtjibli background ekher
{
   
    SDL_Event event;//5tr chn3ml event bich nkiti
    int continuer = 1;
    SDL_Surface *background=NULL;
 SDL_Rect positionbackground;
 
 
 background=IMG_Load("background.png");
 positionbackground.x=0;
 positionbackground.y=0;
    while (continuer)
    {
        SDL_BlitSurface(background,NULL,screen,&positionbackground);
       
        SDL_PollEvent(&event);//programme yok3ed y5dem o wa9t ana n3ml event howa y3mili execution mta3ha 33aks waitevent tstnaik hata ta3tiha event
        switch (event.type)
        {
        case SDL_QUIT:
            continuer = 0;

                            sauvgarder(screen);
        
            break;
        case SDL_KEYDOWN://si chnenzel 3al clavier 
            switch (event.key.keysym.sym)
            {
            case SDLK_ESCAPE:
                continuer = 0;
                printf("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhh");
              
                break;
            }
            break;
        }
        
         SDL_Flip(screen);//refrech

    }

}   






















