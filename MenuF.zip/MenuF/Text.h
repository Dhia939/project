#ifndef TEXT
#define TEXT
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>

typedef struct
{
    SDL_Rect position;
    TTF_Font *font;
    SDL_Surface *surfaceTexte;
    SDL_Color textColor;
    char texte[200];
} Text;

//////////////////////////////
void initText(Text *t);
void freeText(Text A);
void displayText(Text t, SDL_Surface *screen);

#endif /* TEXT */
