#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_image.h>
#include<SDL/SDL_mixer.h>
#include "Text.h"
#include "Music.h"
#include "Menu.h"
/*#define SCREEN_W 940
#define SCREEN_H 600*/

int main(int argc,char* args[])
{


 SDL_Init(SDL_INIT_EVERYTHING);

 SDL_Surface *screen=NULL;
 
 screen = SDL_SetVideoMode(1267,630, 32, SDL_HWSURFACE| SDL_DOUBLEBUF);

 
      sauvgarder(screen);         

 
return 0;
 SDL_Quit();
}
//SDL_LoadBMP()
//gcc main.c -o game -lSDL -lSDL_image -g
