#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include "enemy.h"

void draw_health_bar(SDL_Surface *screen, int health, int max_health, int x, int y, int w, int h) {
    SDL_Rect bg_rect = {x, y, w, h};
    SDL_FillRect(screen, &bg_rect, SDL_MapRGB(screen->format, 0, 0, 0));
    
    SDL_Rect border_rect = {x, y, w, h};
    SDL_FillRect(screen, &border_rect, SDL_MapRGB(screen->format, 255, 255, 255));
    border_rect.x += 1; border_rect.y += 1; border_rect.w -= 2; border_rect.h -= 2;
    SDL_FillRect(screen, &border_rect, SDL_MapRGB(screen->format, 0, 0, 0));
    
    float percentage = (health <= 0) ? 0 : (float)health / max_health;
    int current_width = (int)(percentage * (w - 4));
    
    Uint32 color;
    if (percentage > 0.5) color = SDL_MapRGB(screen->format, 0, 255, 0);
    else if (percentage > 0.25) color = SDL_MapRGB(screen->format, 255, 255, 0);
    else color = SDL_MapRGB(screen->format, 255, 0, 0);
    
    SDL_Rect health_rect = {x + 2, y + 2, current_width, h - 4};
    SDL_FillRect(screen, &health_rect, color);
}

int main(int argc, char *argv[]) {
    int loop = 1;
    SDL_Surface *screen;
    SDL_Event event;
    image IMAGE;
    Ennemi e;
    ES es;
    SDL_Surface *perso = IMG_Load("perso.png");
    if (perso == NULL) {
        printf("Failed to load perso.png: %s\n", SDL_GetError());
        SDL_Quit();
        return -1;
    }
    SDL_Rect posPerso = {10, 450, perso->w, perso->h};
    int direction = -1;
    
    int health = 100;
    const int max_health = 100;
    Uint32 last_hit_time = 0;
    const Uint32 hit_cooldown = 500;

    int level = 1; 

    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_TIMER) == -1) {
        printf("SDL init failed: %s\n", SDL_GetError());
        return -1;
    }

    screen = SDL_SetVideoMode(1920, 1004, 32, SDL_SWSURFACE | SDL_DOUBLEBUF | SDL_RESIZABLE);
    initialiser_imageBACK(&IMAGE);
    initEnnemi(&e, level);
    initES(&es);

    Uint32 start;
    const int FPS = 60;
    while (loop) {
        start = SDL_GetTicks();
        Uint32 current_time = SDL_GetTicks();

        while (SDL_PollEvent(&event)) {
            switch (event.type) {
                case SDL_QUIT:
                    loop = 0;
                    break;
                case SDL_KEYDOWN:
                    switch (event.key.keysym.sym) {
                        case SDLK_RIGHT: direction = 1; break;
                        case SDLK_LEFT:  direction = 0; break;
                        case SDLK_UP:    direction = 3; break;
                        case SDLK_DOWN:  direction = 2; break;
                        case SDLK_l:     level = (level == 1) ? 2 : 1; break; 
			
                    }
                    break;
                case SDL_KEYUP:
                    switch (event.key.keysym.sym) {
                        case SDLK_RIGHT:
                        case SDLK_LEFT:
                        case SDLK_UP:
                        case SDLK_DOWN:
                            direction = -1;
                            break;
                    }
                    break;
            }
        }

        if (direction == 1) posPerso.x += 5;
        if (direction == 0) posPerso.x -= 5;
        if (direction == 3) posPerso.y -= 5;
        if (direction == 2) posPerso.y += 5;

        if (posPerso.x < 0) posPerso.x = 0;
        if (posPerso.x > 1060 - posPerso.w) posPerso.x = 1060 - posPerso.w;
        if (posPerso.y < 0) posPerso.y = 0;
        if (posPerso.y > 594 - posPerso.h) posPerso.y = 594 - posPerso.h;

        afficher_imageBMP(screen, IMAGE);
        SDL_BlitSurface(perso, NULL, screen, &posPerso);
        
        afficherEnnemi(e, screen);
        animerEnemi(&e, posPerso);
        moveIA(&e, posPerso, level);

        afficherES(es, screen);

       
        if (collisionBB(&e, posPerso)) {
            if (current_time - last_hit_time >= hit_cooldown) {
                health -= 20; 
                if (health < 0) health = 0;
                last_hit_time = current_time;

                
                e.health -= 10;
            }
        }

        
        if (collisionBB_ES(&es, posPerso)) {
            if (current_time - last_hit_time >= hit_cooldown) {
                health -= 10; 
                if (health < 0) health = 0;
                last_hit_time = current_time;
            }
        }

        draw_health_bar(screen, health, max_health, 840, 20, 200, 20);

        SDL_Flip(screen);
        if (1000/FPS > SDL_GetTicks() - start)
            SDL_Delay(1000/FPS - (SDL_GetTicks() - start));
    }

    SDL_FreeSurface(IMAGE.img);
    SDL_FreeSurface(perso);
    SDL_FreeSurface(es.sprite);
    SDL_Quit();
    return 0;
}
