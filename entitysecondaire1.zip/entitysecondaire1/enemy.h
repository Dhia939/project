#ifndef ENEMY_H_INCLUDED
#define ENEMY_H_INCLUDED

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>

enum STATE {
    WAITING,
    FOLLOWING,
    ATTACKING
};
typedef enum STATE STATE;

enum HEALTH_STATE {
    ALIVE,
    INJURED,
    NEUTRALIZED
};
typedef enum HEALTH_STATE HEALTH_STATE;

enum DIRECTION {
    LEFT,
    RIGHT
};
typedef enum DIRECTION DIRECTION;

typedef struct {
    SDL_Rect pos_depart;
    SDL_Rect pos_actuelle;
    int direction;
    float vitesse;
    SDL_Surface *spritesheet;
    SDL_Rect pos_sprites;
    int frame;
    int frameCount;
    int frameWidth;
    int frameHeight;
    int displayWidth;  
    int displayHeight; 
    int alive;
    STATE state;
    int health;
    HEALTH_STATE h_state;
    DIRECTION facing;
    Uint32 lastFrameTime; 
    Uint32 frameDelay;   
} Ennemi;

typedef struct {
    SDL_Rect pos;
    SDL_Surface *sprite;
    int displayWidth;
    int displayHeight;
} ES; 

typedef struct {
    char *url;
    SDL_Rect pos_img_affiche;
    SDL_Rect pos_img_ecran;
    SDL_Surface *img;
} image;

void initialiser_imageBACK(image *image);
void afficher_imageBMP(SDL_Surface *screen, image image);

void initEnnemi(Ennemi *e, int level);
void initES(ES *es);
void afficherEnnemi(Ennemi e, SDL_Surface *screen);
void afficherES(ES es, SDL_Surface *screen);
void animerEnemi(Ennemi *e, SDL_Rect posperso);
void moveIA(Ennemi *E, SDL_Rect posperso, int level);
int collisionBB(Ennemi *E, SDL_Rect posPerso);
int collisionBB_ES(ES *es, SDL_Rect posPerso);

#endif
