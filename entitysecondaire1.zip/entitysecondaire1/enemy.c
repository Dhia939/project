#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include "enemy.h"
#include <math.h>

void initialiser_imageBACK(image *image) {
    image->url = "background.png";
    image->img = IMG_Load(image->url);
    if (image->img == NULL) {
        printf("unable to load background image %s \n", SDL_GetError());
    }
    image->pos_img_ecran.x = 0;
    image->pos_img_ecran.y = 0;
    image->pos_img_affiche.x = 0;
    image->pos_img_affiche.y = 0;
    image->pos_img_affiche.w = 1060;
    image->pos_img_affiche.h = 594;
}

void afficher_imageBMP(SDL_Surface *screen, image image) {
    SDL_BlitSurface(image.img, NULL, screen, &image.pos_img_ecran);
}

void initEnnemi(Ennemi *e, int level) {
    e->pos_depart.x = 500;
    e->pos_depart.y = 300;
    e->pos_depart.w = 100; 
    e->pos_depart.h = 100; 

    e->pos_actuelle = e->pos_depart;
    e->direction = rand() % 2;
    e->vitesse = (level == 1) ? 3 : 5;
    e->alive = 1;

    e->spritesheet = IMG_Load("bat.png");
    if (e->spritesheet == NULL) {
        printf("Erreur lors du chargement de la spritesheet bat : %s\n", SDL_GetError());
    }

    e->frame = 0;
    e->frameCount = 11;
    e->frameWidth = 200; 
    e->frameHeight = 200; 
    e->displayWidth = 100;  
    e->displayHeight = 100; 

    e->pos_sprites.x = 0;
    e->pos_sprites.y = 0;
    e->pos_sprites.w = e->frameWidth;
    e->pos_sprites.h = e->frameHeight;

    e->state = WAITING;
    e->health = 100;
    e->h_state = ALIVE;
    e->facing = RIGHT;

    e->lastFrameTime = 0;
    e->frameDelay = 100; 
}


void initES(ES *es) {
    es->pos.x = 700;
    es->pos.y = 400;
    es->pos.w = 35;
    es->pos.h = 35;
    es->displayWidth = 35;
    es->displayHeight = 35;
    es->sprite = IMG_Load("es.png");
    if (es->sprite == NULL) {
        printf("Erreur lors du chargement de ES : %s\n", SDL_GetError());
    }
}

void afficherEnnemi(Ennemi e, SDL_Surface *screen) {
    if (e.alive) {
        SDL_Rect destRect = {e.pos_actuelle.x, e.pos_actuelle.y, e.displayWidth, e.displayHeight};
        SDL_BlitSurface(e.spritesheet, &e.pos_sprites, screen, &destRect);
        SDL_Rect health_rect = {e.pos_actuelle.x, e.pos_actuelle.y - 15, (e.health / 5) * 1.5, 5};
        SDL_FillRect(screen, &health_rect, SDL_MapRGB(screen->format, 255, 0, 0));
    }
}

void afficherES(ES es, SDL_Surface *screen) {
    SDL_Rect destRect = {es.pos.x, es.pos.y, es.displayWidth, es.displayHeight};
    SDL_BlitSurface(es.sprite, NULL, screen, &destRect);
}

void animerEnemi(Ennemi *e, SDL_Rect posperso) {
    if (!e->alive) return;

    Uint32 currentTime = SDL_GetTicks();
    if (currentTime - e->lastFrameTime < e->frameDelay) {
        return;
    }
    e->lastFrameTime = currentTime;

    e->frame = (e->frame + 1) % e->frameCount;
    e->pos_sprites.x = e->frame * e->frameWidth;
    
}

void moveIA(Ennemi *E, SDL_Rect posperso, int level) {
    if (!E->alive || E->h_state == NEUTRALIZED) return;

    
    int dx = abs(E->pos_actuelle.x - posperso.x);
    int dy = abs(E->pos_actuelle.y - posperso.y);

    if (dx <= 600 && dy <= 100) {
        if (dx <= 100 && dy <= 50) {
            E->state = ATTACKING; 
        } else {
            E->state = FOLLOWING; 
        }
    } else {
        E->state = WAITING; 
    }

    
    switch (E->state) {
case WAITING:
    if (level == 1) {
        
        if (E->pos_actuelle.y <= 50) {
            E->direction = 1; 
        } else if (E->pos_actuelle.y >= 500) {
            E->direction = 0; 
        }

        if (E->direction == 1) {
            E->pos_actuelle.y += E->vitesse;
        } else {
            E->pos_actuelle.y -= E->vitesse;
        }
    } else {
        
        static int squareState = 0;
        static int counter = 0;
        const int squareSize = 100;
        const int steps = squareSize / E->vitesse;

       
        switch (squareState) {
            case 0: 
                E->pos_actuelle.x += E->vitesse;
                E->facing = RIGHT;
                break;
            case 1: 
                E->pos_actuelle.y += E->vitesse;
                break;
            case 2: 
                E->pos_actuelle.x -= E->vitesse;
                E->facing = LEFT;
                break;
            case 3: 
                E->pos_actuelle.y -= E->vitesse;
                break;
        }

        
        if (++counter >= steps) {
            counter = 0;
            squareState = (squareState + 1) % 4;
        }
    }
    break;
        case FOLLOWING:
            
            if (E->pos_actuelle.x > posperso.x) {
                E->pos_actuelle.x -= E->vitesse;
            } else if (E->pos_actuelle.x < posperso.x) {
                E->pos_actuelle.x += E->vitesse;
            }
            if (E->pos_actuelle.y > posperso.y) {
                E->pos_actuelle.y -= E->vitesse;
            } else if (E->pos_actuelle.y < posperso.y) {
                E->pos_actuelle.y += E->vitesse;
            }
            break;
        case ATTACKING:
           
            break;
    }

    
    if (E->health <= 0) {
        E->h_state = NEUTRALIZED;
        E->alive = 0;
    } else if (E->health <= 50) {
        E->h_state = INJURED;
    } else {
        E->h_state = ALIVE;
    }
}

int collisionBB(Ennemi *E, SDL_Rect posPerso) {
    if (E->pos_actuelle.x + E->pos_depart.w < posPerso.x ||
        E->pos_actuelle.x > posPerso.x + posPerso.w ||
        E->pos_actuelle.y + E->pos_depart.h < posPerso.y ||
        E->pos_actuelle.y > posPerso.y + posPerso.h) {
        return 0;
    }
    return 1;
}

int collisionBB_ES(ES *es, SDL_Rect posPerso) {
    if (es->pos.x + es->pos.w < posPerso.x ||
        es->pos.x > posPerso.x + posPerso.w ||
        es->pos.y + es->pos.h < posPerso.y ||
        es->pos.y > posPerso.y + posPerso.h) {
        return 0;
    }
    return 1;
}
