#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include "background.h"

int main() {
    bg bg1, bg2;
    char nom[30];
    int choix;
    int guide_shown = 0;

    printf("Jeu individuel (1) ou à deux (2) ? = ");
    scanf("%d", &choix);

    printf("Entrez votre nom : ");
    scanf("%s", nom); // FIX 1 : remplir la variable nom

    init_bg(&bg1);
    init_bg(&bg2);

    if (SDL_Init(SDL_INIT_EVERYTHING) != 0) {
        printf("Erreur SDL_Init: %s\n", SDL_GetError());
        return -1;
    }

    if (TTF_Init() == -1) {
        printf("Erreur TTF_Init: %s\n", TTF_GetError());
        return -1;
    }

    SDL_EnableKeyRepeat(60, 0);

    SDL_Surface *screen = SDL_SetVideoMode(1000, 800, 32, SDL_SWSURFACE);
    if (!screen) {
        printf("Erreur lors de la création de la surface d'écran: %s\n", SDL_GetError());
        return -1;
    }

    afficher_bg(bg1, screen);
    musique(1);

    Uint32 start_time = SDL_GetTicks();

    TTF_Font *font = TTF_OpenFont("font.ttf", 32);
    if (font == NULL) {
        printf("Erreur lors du chargement de la police: %s\n", TTF_GetError());
        return -1;
    }

    SDL_Surface *guide_image = IMG_Load("guide.png");
    if (guide_image == NULL) {
        printf("Erreur lors du chargement de l'image du guide: %s\n", IMG_GetError());
        return -1;
    }
    SDL_Rect guide_image_rect = {0, 0, 1020, 607};

    SDL_Surface *guide_surface = TTF_RenderText_Solid(font, "Guide de jeu", (SDL_Color){255, 255, 255});
    SDL_Rect guide_rect = {10, 100, 150, 30};

    SDL_Surface *time_surface = NULL;
    char time_str[50];

    SDL_Event event;
    int q = 0;

    while (q == 0) {
        SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));

        while (SDL_PollEvent(&event)) {
            switch (event.type) {
                case SDL_QUIT:
                    q = 1;
                    break;
                case SDL_MOUSEBUTTONDOWN:
                    if (event.button.x >= guide_rect.x && event.button.x < guide_rect.x + guide_rect.w &&
                        event.button.y >= guide_rect.y && event.button.y < guide_rect.y + guide_rect.h) {
                        guide_shown = 1;
                    }
                    break;
                case SDL_KEYDOWN:
                    if (guide_shown && event.key.keysym.sym == SDLK_ESCAPE) {
                        guide_shown = 0;
                    }
                    switch (event.key.keysym.sym) {
                        case SDLK_UP:
                            scrolling(&bg1, 2, 20);
                            break;
                        case SDLK_DOWN:
                            scrolling(&bg1, 4, 20);
                            break;
                        case SDLK_LEFT:
                            scrolling(&bg1, 1, 20);
                            break;
                        case SDLK_RIGHT:
                            scrolling(&bg1, 3, 20);
                            break;
                        case SDLK_z:
                            scrolling(&bg2, 2, 20);
                            break;
                        case SDLK_s:
                            scrolling(&bg2, 4, 20);
                            break;
                        case SDLK_q:
                            scrolling(&bg2, 1, 20);
                            break;
                        case SDLK_d:
                            scrolling(&bg2, 3, 20);
                            break;
                        default:
                            break;
                    }
                    break;
                default:
                    break;
            }
        }

        Uint32 current_time = SDL_GetTicks();
        Uint32 elapsed_time = current_time - start_time;
        int seconds = elapsed_time / 1000;
        int minutes = seconds / 60;
        seconds = seconds % 60;

        sprintf(time_str, "Temps: %02d:%02d", minutes, seconds);
        if (time_surface) SDL_FreeSurface(time_surface); // éviter fuite mémoire
        time_surface = TTF_RenderText_Solid(font, time_str, (SDL_Color){255, 255, 255});
        SDL_Rect time_pos = {10, 50};

        animation(&bg1);
        bg_in_borders(&bg1, screen);
        afficher_bg(bg1, screen);

        if (choix == 2) {
            partage_ecran(bg1, bg2, screen);
            animation(&bg2);
            bg_in_borders(&bg2, screen);
        }

        if (time_surface)
            SDL_BlitSurface(time_surface, NULL, screen, &time_pos); // FIX 2

        SDL_BlitSurface(guide_surface, NULL, screen, &guide_rect);

        if (guide_shown)
            SDL_BlitSurface(guide_image, NULL, screen, &guide_image_rect);

        SDL_Flip(screen);
        SDL_Delay(50);
    }

    Score score;
    strcpy(score.name, nom);
    score.score = bg1.camera.x;
    save_score(score); // assure-toi que cette fonction est correcte

    SDL_FreeSurface(guide_image);
    if (time_surface) SDL_FreeSurface(time_surface);
    SDL_FreeSurface(guide_surface);
    TTF_CloseFont(font);
    TTF_Quit();
    SDL_Quit();

    return 0;
}

